---
marp: true
---

[La Légende de Korra - Wikipédia](https://fr.wikipedia.org/wiki/La_L%C3%A9gende_de_Korra)

# *La Légende de Korra*
___

**La Légende de Korra** *(The Legend of Korra)* est une [série d'animation](https://fr.wikipedia.org/wiki/S%C3%A9rie_d%27animation) [américaine](https://fr.wikipedia.org/wiki/%C3%89tats-Unis) créée par [Michael Dante DiMartino](https://fr.wikipedia.org/wiki/Michael_Dante_DiMartino) et [Bryan Konietzko](https://fr.wikipedia.org/wiki/Bryan_Konietzko) et diffusée du [14](https://fr.wikipedia.org/wiki/14_avril) [avril](https://fr.wikipedia.org/wiki/Avril_2012) [2012](https://fr.wikipedia.org/wiki/2012_%C3%A0_la_t%C3%A9l%C3%A9vision) au [19](https://fr.wikipedia.org/wiki/19_d%C3%A9cembre) [décembre](https://fr.wikipedia.org/wiki/D%C3%A9cembre_2014) [2014](https://fr.wikipedia.org/wiki/2014_%C3%A0_la_t%C3%A9l%C3%A9vision) sur la chaîne [Nickelodeon](https://fr.wikipedia.org/wiki/Nickelodeon_(cha%C3%AEne_de_t%C3%A9l%C3%A9vision)). Prévue initialement comme une mini-série de 12 épisodes faisant suite à la série à succès [*Avatar, le dernier maître de l'air*](https://fr.wikipedia.org/wiki/Avatar,_le_dernier_ma%C3%AEtre_de_l%27air), elle comporte finalement un total de 52 épisodes répartis en quatre saisons.

## Généralités

___

En [France](https://fr.wikipedia.org/wiki/France) et en [Belgique francophone](https://fr.wikipedia.org/wiki/Belgique_francophone), le premier épisode fut diffusé le 19 septembre 2012 à 16 h 50 sur [Nickelodeon France](https://fr.wikipedia.org/wiki/Nickelodeon_France) dans sa section Ntoons2. Ensuite, la chaîne [J-One](https://fr.wikipedia.org/wiki/J-One) diffusera la première saison entière, qui est aujourd'hui disponible sur [Canalplay](https://fr.wikipedia.org/wiki/Canalplay). À partir du 3 juillet 2017, [France 4](https://fr.wikipedia.org/wiki/France_4) diffuse à son tour la série entière.

La série a changé de nom plusieurs fois avant sa diffusion. Appelée initialement *Avatar: Legend of Korra*, elle était conçue au départ pour être une mini-série de 12 épisodes, qui serait diffusée à partir du 14 avril 2012. Devant son succès, elle a ensuite été reconduite pour 14 épisodes supplémentaires, qui couvriront le 2e livre. Finalement, Nickelodeon a renouvelé la série pour une deuxième saison de 26 épisodes qui sera divisée en deux afin de couvrir le 3e et 4e livre. Ces deux premiers livres formeront la première saison de la série tandis que les troisième et quatrième formeront la deuxième saison. Le titre a alors été changé afin de devenir *The Last Airbender: Legend of Korra (le Dernier Maître de l'Air : la Légende de Korra)*. Le 14 mars 2012, le nom a encore une fois été changé pour devenir enfin *The Legend of Korra (La Légende de Korra)*. La série s'achève à la quatrième saison, il n'est pas prévu qu'une cinquième ait lieu. 

## Synopsis

___

Korra est un maître de l'eau venant du Pôle Sud, elle est également la fille du chef de la tribu du Pole du Sud, qui a un fort caractère. En tant qu'Avatar, elle doit apprendre à maîtriser les quatre éléments. Les maîtrises de l'eau, de la terre et du feu et l'air lui ont été enseignées pendant toute son enfance au pôle sud par les maîtres du Lotus Blanc, cependant elle n'arrive pas à contrôler à la perfection sa maitrise de l'air. Au début de la série, elle part vivre à la Cité de la République pour apprendre la maîtrise de l'air auprès de Tenzin, le dernier maître de l'air. La Cité de la République a été créée par Aang et Zuko après cent ans de guerre et abrite des gens de toutes les nations.

Dans la série, plusieurs nouveaux personnages ont un lien avec les anciens. Par exemple, Korra apprendra à maîtriser l'air avec Tenzin, l'un des trois enfants de Katara et Aang. Lin Beifong est non seulement le chef de la police de la Cité de la République mais aussi la fille de Toph, qui a appris à ses filles et aux policiers la maîtrise du métal.

Le monde a également connu une grande modernisation, la Cité de la République ressemble au [New York](https://fr.wikipedia.org/wiki/New_York) et au [Shanghai](https://fr.wikipedia.org/wiki/Shanghai) de 1920 (avenues, gratte-ciels, véhicules à moteur, tramways, paquebots à vapeur, dirigeables). Cette évolution technologique qui a permis aux gens de s'affranchir de la maîtrise des éléments dans la vie de tous les jours (eau courante, [électricité](https://fr.wikipedia.org/wiki/%C3%89lectricit%C3%A9), chauffage, transports, radios, [appareils photos](https://fr.wikipedia.org/wiki/Appareil_photographique), micro et haut-parleur) a aussi donné naissance à des mouvements anti-maîtrise de plus en plus nombreux dans la ville.

Au fur et à mesure, la série prend une tournure de plus en plus politique et philosophique, ainsi que plus de maturité.

## Distribution
___

### **Voix originales**

___

- [Janet Varney](https://en.wikipedia.org/wiki/Janet_Varney) : Korra
- [David Faustino](https://fr.wikipedia.org/wiki/David_Faustino) : Mako
- [P. J. Byrne](https://fr.wikipedia.org/wiki/P._J._Byrne) : Bolin
- [Seychelle Gabriel](https://fr.wikipedia.org/wiki/Seychelle_Gabriel) : Asami Sato
- [J. K. Simmons](https://fr.wikipedia.org/wiki/J._K._Simmons) : Tenzin
- [Kiernan Shipka](https://fr.wikipedia.org/wiki/Kiernan_Shipka) : Jinora
- [Darcy Rose Byrnes](https://fr.wikipedia.org/wiki/Darcy_Rose_Byrnes) : Ikki
- [Logan Wells](https://fr.wikipedia.org/w/index.php?title=Logan_Wells&action=edit&redlink=1) : Meelo
- [Maria Bamford](https://fr.wikipedia.org/w/index.php?title=Maria_Bamford&action=edit&redlink=1) : Pemma
- [Mindy Sterling](https://fr.wikipedia.org/wiki/Mindy_Sterling) : Lin Beifong
- [Steven Blum](https://fr.wikipedia.org/wiki/Steven_Blum) : Amon
- [Lance Henriksen](https://fr.wikipedia.org/wiki/Lance_Henriksen) : Lieutenant
- [Richard Epcar](https://fr.wikipedia.org/wiki/Richard_Epcar) : Capitaine Saikhan
- [Daniel Dae Kim](https://fr.wikipedia.org/wiki/Daniel_Dae_Kim) : Hiroshi Sato
- [Dee Bradley Baker](https://fr.wikipedia.org/wiki/Dee_Bradley_Baker) : Tarrlok, Naga et Pabu
- [Dante Basco](https://fr.wikipedia.org/wiki/Dante_Basco) : Iroh
- [Eva Marie Saint](https://fr.wikipedia.org/wiki/Eva_Marie_Saint) : Katara
- [Richard Riehle](https://fr.wikipedia.org/wiki/Richard_Riehle) : Bumi
- [Lisa Edelstein](https://fr.wikipedia.org/wiki/Lisa_Edelstein) : Kya
- [Anne Heche](https://fr.wikipedia.org/wiki/Anne_Heche) : Suyin Beifong
- [Zelda Williams](https://fr.wikipedia.org/wiki/Zelda_Williams) : Kuvira

**Photos des comédiens de la distribution des protagoniste principaux de la série**  
![Janet Varney](/Janet_Varney_by_Gage_Skidmore.jpg) ![Seychelle Gabrielle](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Seychelle_Gabriel_by_Gage_Skidmore.jpg/149px-Seychelle_Gabriel_by_Gage_Skidmore.jpg) ![David Faustino](https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/David_Faustino_by_Gage_Skidmore.jpg/140px-David_Faustino_by_Gage_Skidmore.jpg) ![P. J. Byrne](https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/P._J._Byrne_by_Gage_Skidmore.jpg/157px-P._J._Byrne_by_Gage_Skidmore.jpg) ![J. K. Simmons](https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/JK_Simmons_2009.jpg/132px-JK_Simmons_2009.jpg) ![Mindy Sterling](https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Mindy_Sterling_by_Gage_Skidmore_2.jpg/142px-Mindy_Sterling_by_Gage_Skidmore_2.jpg) ![Kiernan Shipka](https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/Kiernan_Shipka_at_PaleyFest_2014_HQ.jpg/130px-Kiernan_Shipka_at_PaleyFest_2014_HQ.jpg) ![Dee Bradley Baker](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Dee_Bradley_Baker_by_Gage_Skidmore_3.jpg/159px-Dee_Bradley_Baker_by_Gage_Skidmore_3.jpg)

### **Voix françaises**

___

- Lutèce Ragueneau : Korra                                             
- [Olivier Martret](https://fr.wikipedia.org/wiki/Olivier_Martret) : Mako
- Alexandre Nguyen : Bolin
- [Jessica Monceau](https://fr.wikipedia.org/wiki/Jessica_Monceau) : Asami
- [Guy Chapellier](https://fr.wikipedia.org/wiki/Guy_Chapellier) : Tenzin
- [Alexandra Pic](https://fr.wikipedia.org/wiki/Alexandra_Pic) : Ikki
- Pauline Moingeon Vallès : Pemma
- Sophie Riffont : Lin Beifong
- [Sophie Arthuys](https://fr.wikipedia.org/wiki/Sophie_Arthuys) : Suyin Beifong
- [Paul Borne](https://fr.wikipedia.org/wiki/Paul_Borne) : Amon (saison 1)
- [Philippe Crubézy](https://fr.wikipedia.org/w/index.php?title=Philippe_Crub%C3%A9zy&action=edit&redlink=1) : Hiroshi Sato (saison 1 et 3)
- [Axel Kiener](https://fr.wikipedia.org/wiki/Axel_Kiener) : Tarrlok (saison 1)
- [Marie-Martine](https://fr.wikipedia.org/wiki/Marie-Martine_(actrice)) : Katara
- [Gilbert Lévy](https://fr.wikipedia.org/wiki/Gilbert_L%C3%A9vy) : Bumi
- [Véronique Soufflet](https://fr.wikipedia.org/wiki/V%C3%A9ronique_Soufflet) : Kya
- [Benoît Du Pac](https://fr.wikipedia.org/wiki/Beno%C3%AEt_Du_Pac) : Varrick
- [Boris Rehlinger](https://fr.wikipedia.org/wiki/Boris_Rehlinger) : Tonraq et le lieutenant d'Amon
- [Alexis Tomassian](https://fr.wikipedia.org/wiki/Alexis_Tomassian) : Zuko
- [Pierre-François Pistorio](https://fr.wikipedia.org/wiki/Pierre-Fran%C3%A7ois_Pistorio) : Shiro Shinobi, le commentateur et narrateur ; Aiwei, le bras droit de Suyin,
- [Guillaume Orsat](https://fr.wikipedia.org/wiki/Guillaume_Orsat) : le président Raiko
- [Patrice Melennec](https://fr.wikipedia.org/wiki/Patrice_Melennec) : Iroh
- [Thierry Ragueneau](https://fr.wikipedia.org/wiki/Thierry_Ragueneau) : Zaheer (saison 3)
- [Anne Massoteau](https://fr.wikipedia.org/wiki/Anne_Massoteau) : P'Li (saison 3)
- [Benjamin Bollen](https://fr.wikipedia.org/wiki/Benjamin_Bollen) : le prince Wu (saison 4)
- Ludivine Maffren : Kuvira (saison fin de 3 et toute la 4)
- [Gauthier de Fauconval](https://fr.wikipedia.org/wiki/Gauthier_de_Fauconval) : Baatar Jr (saison 4)

## Personnages
 
___

### **Personnages principaux**

___

- **Korra**
Âgée de 17 ans au début de la série, elle est le nouvel Avatar après Aang. Elle est issue de la tribu de l'eau du Pôle Sud et est décrite comme une fille entêtée et indocile. Elle a des yeux bleu ciel et des cheveux bruns attachés qu'elle laisse parfois libres. Elle finira par avoir des cheveux courts (elle se les coupera dans la saison 4). Au début de l'animé, elle a déjà la maîtrise de l'eau, de la terre et du feu, mais elle doit apprendre celle de l'air sous la tutelle de Tenzin. Elle éprouve des difficultés à assimiler cette maîtrise car elle n'a jamais appréhendé le côté spirituel de son rôle d'Avatar, préférant se concentrer sur l'aspect physique. Dans le 12e épisode du premier livre, Amon la prive de sa maîtrise élémentaire. Au moment où il tente de faire la même chose à Mako, elle se découvre la maîtrise de l'air et bat Amon avec. Dans le deuxième livre elle rencontre son oncle Unalaq, fera la connaissance des esprits et découvrira la vérité sur Wan le premier Avatar. Elle combattra Vaatu l'esprit des Ténèbres et du Chaos et son oncle qui ont fusionné pour donner un Avatar maléfique et malheureusement perdra sa connexion avec ses vies antérieures. Elle apprend la maîtrise du métal dans le troisième livre grâce à Suyin Beifong, la deuxième fille de Toph et combattra le Lotus Rouge. Empoisonnée par ceux-ci, elle sera guérie par Suyin mais reste encore très faible. Trois ans plus tard, elle reprend une nouvelle vie et essaie de guérir avec l'aide de Toph Beifong. Sa nouvelle ennemie sera Kuvira qui veut unifier le Royaume de la Terre avec une vision tyrannique.

> *"Even Though We Should Learn From Those Who Came Before Us, We Must Also Forge Our Own Path."*
>
> -- **Avatar Korra**

- **Mako**
C'est un maître du feu de 18 ans au début de la série, aux cheveux noirs et aux yeux ambres. Est un des amis de Korra. Il est plutôt renfermé, rêveur et calme. Après le meurtre de ses parents par un maître du feu, il a grandi dans la rue avec son jeune frère Bolin. Il est aussi un pro-maître dans l'espoir de gagner le gros lot et fait partie de la police.
Sa maîtrise de l'électricité lui assure un emploi à la centrale énergétique. Il est en couple avec Asami, la fille du grand constructeur automobile Hiroshi Sato, et ce malgré le fait que Korra lui ait avoué ses sentiments. Des tensions apparaîtront dans le couple Mako-Asami dont Korra est la cause. Asami est certaine que Mako aime Korra, à raison. Ils rompent quelques épisodes avant la fin du premier livre. Il déclare alors sa flamme au jeune Avatar et s'embrassent. Durant le deuxième livre, on apprend qu'ils sortent ensemble depuis six mois et qu'ils ont tous deux arrêté les tournois de pro-maître.
&nbsp;
- **Bolin**
Il est lui un des amis de Korra. Maître de la terre âgé de 16 ans au début de la série, il est le petit frère de Mako. Contrairement à ce dernier, Bolin est souvent insouciant, très enthousiaste et plein d'humour. Il participe lui aussi aux tournois des pro-maîtres, le sport le plus populaire de la Cité de la République. Il entretient un lien très fort avec Mako, malgré son léger sentiment d'infériorité. Il est amoureux de Korra mais tourne la page quand il se rend compte que Korra aime Mako et sera plus tard amoureux d'Opal, la fille de Suyin. Dans le deuxième livre, il devient une star de cinéma et est très proche d'Asami. Bien qu'incapable de maîtriser le métal, il apprendra à maîtriser la lave dans le troisième livre.
&nbsp;
- **Asami Sato**
Asami est la petite-amie de Mako (comme montré dans les comics). Elle ne possède pas de maîtrise d'élément. Elle est la fille de Hiroshi Sato, l'industriel le plus riche de la cité et l'inventeur de la Satomobile. Asami a 18 ans au début de la série et a vécu dans le luxe toute sa vie mais en dépit de ses bonnes manières, elle peut être très dure. C'est une conductrice experte et une as de la [mécanique](https://fr.wikipedia.org/wiki/M%C3%A9canique_(technique)), d'ailleurs elle possède comme arme des gants électriques. Son père a tenu à ce qu'elle bénéficie de la meilleure formation possible en [auto-défense](https://fr.wikipedia.org/wiki/Autod%C3%A9fense). Elle est aussi une grande fan du tournoi des pro-maîtres et assiste à chaque match. Elle se met brièvement en couple avec Mako à trois reprises, d'abord durant la saison 1 (par deux fois) puis 2.
&nbsp;
- **Tenzin**
Tenzin est l'initiateur de Korra à la maîtrise de l'air. Âgé de 51 ans, il est le plus jeune des enfants d'Aang et Katara et le seul qui maîtrise l'air. Il a quatre enfants, tous maîtres de l'air et vit sur l'île du Temple de l'air, un sanctuaire construit par Aang après 100 ans de guerre. C'est à cet endroit que Korra s'est installée pour son entraînement à la maîtrise de l'air. Il est également Conseiller au Gouvernement de la Cité de la République. Plus jeune, il est sorti avec Lin Beifong, l'une des filles de Toph. Plus tard, il démissionnera de ses fonctions au conseil de la ville pour se concentrer sur la formation des nouveaux maîtres de l'air suite à la convergence harmonique.
&nbsp;
- **Naga**
Naga est une chienne-ours polaire. Elle est l'animal de compagnie et le guide de Korra. Le chien polaire a été imaginé durant l'écriture des premiers *Avatar, le dernier maître de l'air*, mais n'a finalement pas été inclus dans la série originale
&nbsp;
- **Jinora**
Elle est la fille aînée de Tenzin et a 10 ans. Elle est maître de l'air, une avide lectrice et très sage. Elle adore l'histoire de l'avatar Aang et de ses amis durant la guerre de 100 ans et s'interroge même sur le destin de la mère de Zuko. Avec son frère et sa sœur, elle assiste leur père dans la formation de Korra et se bat courageusement lors de l'attaque des Equalizers. Pendant le deuxième livre, elle commence à développer un lien étroit avec le monde spirituel alors même que son propre père n'a pas de connexion. Elle devient la guide de Korra dans le monde spirituel mais finit pas s'y perdre et se retrouve dans le Brouillard des âmes perdues. Elle est secourue par Tenzin, Kya et Bumi mais décide de rester dans le monde spirituel car elle a une dernière mission à y effectuer: retrouver Raava. Durant la bataille face à Unalaq, elle permet à Korra de sauver l'âme de Raava. Durant le troisième livre, elle forme avec son père, sa sœur et son frère les nouveaux maîtres de l'air qui se sont révélés grâce à la convergence harmonique. Elle se rapproche notamment du jeune Kai. À la fin du troisième livre, elle crée une gigantesque tornade avec l'aide de ses disciples et sauve Korra de Zaheer. Elle obtient finalement des tatouages du maître de l'air en récompense de son courage. Dans le livre 4, elle est choisie par son père pour retrouver Korra. Elle se fait capturer par les esprits des lianes et est sauvée par l'intervention de Korra. Avec Opal, elle sauve Korra de Kuvira pui finit par participer à la bataille de Republic City contre le Mécha-Robot.
&nbsp;
- **Lin Beifong**
Elle est la fille de Toph, 50 ans, et le général des forces de police de la Cité de la République, poste qu'occupait sa mère auparavant. C'est d'ailleurs Toph elle-même qui a formé la police à la maîtrise du métal afin de capturer plus efficacement les criminels. Lin estime au premier abord que Korra est une menace pour la Cité de la République et met tout en œuvre pour contenir les batailles souvent destructrices de l'Avatar. Par la suite, elle devient plus tolérante vis-à-vis de Korra et conjugue ses forces avec elle dans la lutte contre Amon. Elle est sortie avec Tenzin dans sa jeunesse. Durant l'attaque du temple de l'air, elle sauve la famille de Tenzin et se fait capturer par Amon, qui lui enlève (provisoirement) sa maîtrise. Durant le livre 3, elle accompagne Korra à Zaofu, ville dirigée par sa jeune sœur. L'histoire de ses deux sœurs ennemies refait alors surface, ce qui la rend malade jusqu'à que les sœurs se battent et finissent finalement par se réconcilier. Elles sauvent par la suite Korra d'un enlèvement par le Lotus Rouge, puis font faceà et battent la terrible P'Li. Pendant le tome 4, elle va secourir sa sœur et sa famille en compagnie de Bolin et Opal et finit également par se réconcilier avec sa mère, Toph. Lors de la bataille de Républic City, elle s'infiltre dans le Mécha-Robot avec Suyin et les deux sœurs parviennent à détruire le bras-canon.

### **Personnages secondaires**

___

- **Pemma**
C'est la femme de Tenzin, elle ne maîtrise aucun élément. Âgée de 35 ans, elle est la mère de Jinora, Ikki, Meelo et Rohan et elle a du mal à gérer la situation de ses enfants qui maîtrisent tous l'élément de l'air. Au début de la série, elle est enceinte de Rohan, dont elle espère qu'il ne maîtrisera aucun élément mais sa belle-mère, Katara, a le pressentiment d'un autre maître de l'air, malheureusement pour elle. C'est une mère et une épouse toujorus très présente. Lors de la bataille de Républic City, elle s'occupera d'aider et de réconforter les citoyens fuyant le conflit.
&nbsp;
- **Ikki**
Elle est le deuxième enfant de Tenzin, petite sœur de Jinora. Elle est âgée de 7 ans et est décrite comme joyeuse, agitée et bavarde. Elle est aussi une maître de l'air.
&nbsp;
- **Meelo**
Il est le troisième enfant et le premier fils de Tenzin, le petit frère âgé de 5 ans d'Ikki et de Jinora et grand-frère de Rohan. Il aime beaucoup sa famille et a hérité du pouvoir de l'air de son père. Il est très comique, puéril et a un faible pour Asami. Lors de l'attaque des Égalitaristes sur l'île du temple de l'air, il a affronté plusieurs bloqueurs de chi avec l'aide de ses sœurs et ce avec une facilité étonnante.
&nbsp;
- **Rohan**
Rohan est le dernier enfant et second fils de Tenzin, il naît vers la fin du premier livre, sur l'île du temple de l'air de la Cité de la République pendant l'invasion des Égalitaristes. Selon Katara, il maîtrisera l'air lui aussi.
&nbsp;
- **Katara**
Elle est maintenant une femme âgée et l'un des rares personnages vivants de *Avatar, le dernier maître de l'air*. Elle est le maître qui a initié Korra à la maîtrise de l'eau. Elle lui a notamment enseigné les techniques de guérison de la maîtrise de l'eau.
&nbsp;
- **[Toph Beifong](https://fr.wikipedia.org/wiki/Toph)**
Désormais âgée, elle est un des rares personnages vivants d’[Avatar](https://fr.wikipedia.org/wiki/Avatar,_le_dernier_ma%C3%AEtre_de_l%E2%80%99air) avec Katara et Zuko. Mère de Lin et Suyin, elle disparait et vit en ermite dans le marais des esprits. Korra croisera Toph qui l’aidera à se libérer du poison métallique que le Lotus rouge lui a administré.
&nbsp;
- **Bumi**
Bumi est l’aîné des trois enfants d'Aang et Katara, et le seul à ne pas avoir de maîtrise contrairement à Kya qui maîtrise l'eau et à Tenzin qui maîtrise l'air. Le nom Bumi vient d'un grand ami d'Aang qui portait le même prénom (vu dans la première série). Avant de partir à la retraite, il était le commandant de la deuxième division des forces unies. Après la Convergence Harmonique, Bumi s'entraîne à maîtriser l'air.
&nbsp;
- **Kya**
Kya est la fille d'Aang et Katara, sœur ainée de Tenzin et cadette de Bumi. Le nom Kya était celui de sa grand-mère maternelle. Elle a hérité de la maîtrise de l'eau de sa mère. On apprend dans les comics qu'elle est lesbienne.
&nbsp;
- **Varick**
Est un génie que l'on croise dans le deuxième livre, qui aidera et qui sera un personnage très utile. Au début uniquement attiré par l’appât du gain, il aura une bonne voix dans sa tête (livre 4) qui lui dira de faire de bonnes actions. Il ne maîtrise aucun élément mais est quand même un personnage redoutable.
&nbsp;
- **Zhu Li**
Est l'assistante fidèle et servile de Varick. Elle remplit toutes les tâches que son excentrique employeur lui demande.
&nbsp;
- **Hiroshi Sato**
Hiroshi est un homme d'affaires très puissant. Son ascendance familiale s'étend jusqu'aux premières colonies de la Nation du feu. Il a grandi dans la pauvreté mais à force de détermination a développé et fabriqué la « Sato-mobile », la Cité de la République décrit cette invention comme équivalente au « Model-T » de [Ford](https://fr.wikipedia.org/wiki/Henry_Ford). Il est aussi le père d'Asami. Il est le fournisseur d'Amon de manière secrète car il veut se venger des maîtres qui ont assassiné son épouse.
&nbsp;
- **Suyin Beifong**
Suyin Beifong est la fille de Toph et la demi-sœur de Lin. Elle maîtrise le métal et dirige une école où elle transmet ses compétences à ses élèves.
&nbsp;
- **Opal Beifong**
Opal est un maître de l'Air, mais aussi la fille de Suyin Beifong et donc par la même occasion la petite-fille de Toph Bei Fong, étant ainsi membre du Clan du Métal de Zaofu. Elle a rejoint la Nation de l'Air peu après la Convergence Harmonique, après que de nouveaux maîtres de l'Air apparaissent de nouveau. Elle tombe amoureuse de Bolin, mais leur relation souffre de l'engagement de Bolin au service de Kuvira.
&nbsp;
- **Saikhan**
Il est le capitaine des maîtres du métal qui travaille à la Cité de la République sous les ordres de Lin Beifong. Lorsque celle-ci est blessée, il la remplace en tant que commissaire. Il est à la solde du conseiller Tarrlok.
&nbsp;
- **Tarrlok**
Conseiller au Gouvernement de la Cité de la République et représentant de la Tribu de l'Eau du Nord, il est chargé de la sécurité au sein de la ville. Il est le principal opposant politique de Tenzin. C'est également un maître de l'eau et on apprend plus tard qu'il est également un maître du sang et le frère de Amon (Noatak).
&nbsp;
- **Amon**
De son vrai nom Noatak, c'est le leader des Égalitaristes, une organisation qui réprouve toute maîtrise des éléments. Il est inexplicablement capable de bloquer le chi de ses adversaires afin de les priver temporairement ou éternellement de leur maîtrise des éléments. Il réussit ce tour de force grâce à la maîtrise du sang, faculté étonnante et interdite, normalement utilisable que lors de la pleine lune. Il est révélé en fin de saison qu'Amon est le fils de Yakone et le frère du conseiller Tarrlok.
&nbsp;
- **Lieutenant**
Il seconde Amon à la tête de l'organisation des Égalitaristes. C'est un combattant hors pair, capable d'augmenter ses compétences au combat grâce à deux gourdins chargés en électricité.
&nbsp;
- **Tonraq**
Tonraq est le père de Korra et le frère aîné de Unalaq, à qui il est fermement opposé dès le départ.
&nbsp;
- **Senna**
Senna est la mère de Korra et la femme de Tonraq.
&nbsp;
- **Unalaq**
Unalaq est le frère cadet de Tonraq et le père de Desna et Eska. Il veut libérer Vattu afin de répandre de nouveau le chaos mais aussi pour fusionner avec lui dans le but de devenir l'Avatar sombre. Il sera finalement tué par sa nièce Korra mais aura tout de même réussi à réunir les humains et les esprits.
&nbsp;
- **Desna et Eska**
Desna et Eska sont le fils et la fille d'Unalaq et les cousins [jumeaux](https://fr.wikipedia.org/wiki/Jumeau) de Korra. Sombres et nonchalants, ils étaient prêts à tout pour aider leur père jusqu'à ce qu'il utilise l'énergie de la Convergence Harmonique afin de devenir l'Avatar sombre. Se rendant compte que leur père ne pourrait être sauvé, ils finirent par aider Korra et les autres à le vaincre.
&nbsp;
- **Iroh**
C'est le petit-fils de Zuko, il a été prénommé ainsi en souvenir d'Iroh, l'oncle de son grand-père (personnage de la première série). Il est le plus jeune général de l'armée des Nation-Unies. C'est un maître du feu.
&nbsp;
- **Kuvira**
Elle apparaît dans le dernier épisode du troisième livre comme membre des équipes de sauvetage. Au début du dernier livre, elle est capitaine du clan du Métal et elle a mis en place un plan de « réunification » du royaume de la Terre. Elle sécurise le royaume provinces par provinces, puis renverse le prince Wu, futur roi de la terre, durant son [couronnement](https://fr.wikipedia.org/wiki/Couronnement). Très autoritaire et charismatique, cette redoutable maître de la terre va transformer le Royaume de la Terre en un Empire de la Terre dont elle devient l'impératrice auto-proclamée. Elle va finir par prendre le contrôle entier du Royaume de la Terre et va attaquer la Cité de la République dont elle revendique le territoire (historiquement appartenant au Royaume de la Terre). Après sa défaite face à l'Avatar Korra, l'Empire de la Terre, à peine créé, va se transformer en une fédération où les provinces obtiennent une large autonomie.
&nbsp;
- **Zaheer**
Zaheer est un maître de l'air qui veut éliminer le nouvel Avatar dans le troisième livre. Il empoisonnera Korra avec du [mercure](https://fr.wikipedia.org/wiki/Mercure_(chimie)) que Su Beifong arrivera à éliminer. Korra sera quand même grièvement blessée avant qu'elle n'en finisse avec Zaheer.
&nbsp;
- **Pabu**
Pabu est le furet de feu de Bolin. Il ressemble à un croisement entre un raton-laveur et un panda-roux. Il est la mascotte de l'équipe des pro-maîtres et est capable de nombreuses facéties et numéros de cirque appris par Bolin.
&nbsp;
- **Wu**
Wu est le [prince héritier](https://fr.wikipedia.org/wiki/Prince_h%C3%A9ritier) du Royaume de la Terre à la suite de la mort de sa grand-tante. C'est un *playboy* insouciant.

## Saisons 

___

### _**Livre un : L'air**_

**Résumé**: Korra, la nouvelle Avatar, maîtrise parfaitement l'Eau, la Terre et le Feu et doit maintenant se consacrer à l'Air. Pour ce faire, Katara demande l'aide de son fils Tenzin, un des derniers maître de l'air avec ses enfants Jinora, Ikki et Meeloo. Contre l'avis du Lotus Blanc mais avec la bénédiction de Katara, Korra quitte le Pôle Sud avec sa fidèle Naga et rejoint Tenzin et sa famille à Républic City. Tenzin y officie comme conseiller auprès au Gouvernement de la ville de Républic City en compagnie de Tarrlok, un membre de la Tribu de l'eau du Pôle Nord. Korra découvre une ville au fonctionnement compliqué et se retrouve face à Lin Beinfong, cheffe de la police et maître du Métal. Elle rejoint également une équipe participant au Tournoi des Maîtres, une compétition promettant richesse aux vainqueurs. Ses coéquipiers sont Mako, un maître du feu, et Bolin, un mettre de la terre (et son furet Pabbu), qui sont tous deux des frères orphelins; Ils sont soutenus par Asami, la fille de l'inventeur Hiroshi Sato. Mais une menace rode dans la ville: Amon, un charismatique leader, mène un groupe Anti-Bending qui se bat pour l'égalté des humains ne sachant pas maîtriser un élément. De plus, Amon a le terrifiant pouvoir de retirer la maîtrise d'une personne...

### _**Livre deux : Les Esprits**_

**Résumé**: Tentant de renouer avec la tribu de l'eau du Pôle Nord, Korra accepte l'invitation de son oncle Unalaq (le frère de Tonraq, son père) afin d'assister à un festival. Elle y rencontre ses cousins Eska et Desna. Le festival est troublé par l'attaque d'esprits, qu'Unalaq arrive à calmer en utilisant sa maîtrise de l'eau. Korra, dont la mission d'Avatar est d'être un pont entre le monde des Humains et celui des Esprits, lui demande alors de le former malgré la réticence de Tonraq et de Tenzin. Mais Unalaq révèle sa vraie nature en attaquant la tribu du Pôle Sud pour de vielles querelles malgré les stratagèmes de Tonraq et de l'inventeur Varrick. Mako et Asami tentent d'aider leur amie tandis que Bolin devient acteur et tourne dans des publicités de propagande contre la guerre avec Varrick. De son côté, Tenzin doit gérer le retour de Kya et de Bumi, son frère et sa sœur, pendant que sa fille Jinora commence à fortement développer sa spiritualité.Elle devient un guide pour Korra dans le monde des Esprits, où elle y retrouve Iroh et apprend l'histoire du premier avatar, Wan, qui a fusionné avec Raava, l'esprit du Bien, et banni Vaatu, l'esprit du Mal qui peut corrompre les autres esprits. Vaatu peut cependant s'échapper de sa prison lors de la Convergence Harmonique, un évènement rare, pendant lequel l'Avatat et Raava doivent fusionner. Mais Korra, toujours affectée par les techniques d'Amon, n'est plus connectée avec les anciens Avatars et donc avec Raava. Vaatu, aidé par Unalaq, n'a jamais été aussi proche de retrouver sa liberté et de commencer une ère de Ténèbres.

### _**Livre trois : Le Changement**_

**Résumé**: Depuis que Korra a décidé de laisser les esprits vivre dans le monde des Humains, ceux-ci ont envahi une partie de la ville et provquent la colère de Raiko mais également de nombreux habitants de Republic City. Mais la convergence harmonique a un nouvel effet : elle fait apparaître de nouveaux maîtres de l'air, parmi lesquels le jeune Kai, Opal, mais aussi Bumi, le frère de Tenzin. Aidé de ses enfants, de Kya et de Korra et ses amis, Tenzin tente de regrouper et de former ses nouveaux disciples en arpentant tous les royaumes. Cela amène Lin à retrouver sa demi-sœur Suyin (la mère d'Opal) avec laquelle elle entretient des rapports très houleux depuis leur adolescence. Mako et Bolin renouent également avec de la famille éloignée à Ba-Sing-Se. Zaheer, un ancien terroriste, acquiert également ce nouveau don et libère ses trois acolytes P-Li, Ming-Hua et Ghazan malgré l'intervention de Zuko, Eska et Desna. Ce groupe, appelé le Lotus Rouge, est une dangereuse organisation luttant pour la liberté en ayant comme seul but de tuer l'Avatar.

### _**Livre quatre : L'Équilibre**_

**Résumé**: Après les évènements du livre précédent, Korra a renoncé à sa fonction d'avatar et erre, poursuivie par des démons intérieurs, jusqu'à ce qu'elle rencontre la seule personne qui puisse l'aider: Toph. Mako, de son côté, est le garde du corps du prince Wu destiné à devenir le nouvel empereur du Royaume de la Terre après le meurtre de la précédente reine par Zaheer. Mais Kuvira, surnommée la Grande Unificatrice après avoir réussi à réunifier de nombreuses régions du royaume, s'oppose à ce couronnement et souhaite désormais proclamer l'irréndentisme du Royaume de la Terre. Elle est soutenue dans son projet par l'inventeur Varrick et son assistante Zhu Li, mais aussi par Bolin et Baatar Jr. A l'inverse, Suyin et sa famille s'opposent à la montée en puissance de ce royaume belliqueux. Pour éviter que la guerre fasse rage, Tenzin charge Jinora, Ikki et Meeloo de retrouver Korra. Mais la guerre finit par frapper aux portes de Republic City et Raiko et Lin peinent à convaincre les autres royaumes de les aider. Pour arriver àvaincre Kuvira, Asami fait libérer son père Hiroshi de prison et Korra trouve un allé innatendu en la personne de son ancien ennemi Zaheer.


## Liste des épisodes
1. _**Livre un : L'air**_
    1. Saison 1 (12 épisodes)
        1. Bienvenue dans la Cité de la République (*Welcome to Republic City*) - 14 avril 2012
        2. Comme une feuille au vent (*A Leaf in the Wind*) - 14 avril 2012
        3. La révélation (*The Revelation*) - 21 avril 2012
        4. Une voix dans la nuit (*The Voice in the Night*) - 28 avril 2012
        5. L'esprit de compétition (*The Spirit of Competition*) - 5 mai 2012
        6. Et le gagnant est... (*And the Winner Is...*) - 12 mai 2012
        7. Contrecoup (*The Aftermath*) - 19 mai 2012
        8. Quand les extrêmes se rencontrent (*When Extremes Meet*) - 2 juin 2012
        9. Les leçons du passé (*Out of the Past*) - 9 juin 2012
        10. Changement de cap (*Turning the Tides*) - 16 juin 2012
        11. Des squelettes dans le placard (*Skeletons in the Closet*) - 23 juin 2012
        12. Phase finale (*Endgame*) - 23 juin 2012
2. _**Livre deux : Les Esprits**_
    1. Saison 2 (14 épisodes)
        1. Esprit rebelle (*Rebel Spirit*) - 13 septembre 2013
        2. Les aurores australes (*The Southern Lights*) - 13 septembre 2013
        3. Guerres civiles, 1ère partie (*Civil Wars, Part 1*) - 20 septembre 2013
        4. Guerres civiles, 2ème partie (*Civil Wars, Part 2*) - 27 septembre 2013
        5. Les gardiens de la paix (*Peacekeepers*) - 4 octobre 2013
        6. Coup monté (*The Sting*) - 11 octobre 2013
        7. Le Commencement, 1ère partie (*Beginnings, Part 1*) - 18 octobre 2013
        8. Le Commencement, 2ème partie (*Beginnings, Part 2*) - 18 octobre 2013
        9. Le guide (*The Guide*) - 1er novembre 2013
        10. Le nouvel âge spirituel (*A New Spiritual Age*) - 8 novembre 2013
        11. La nuit des étoiles (*Night of a Thousand Stars*) - 15 novembre 2013
        12. La convergence harmonique (*Harmonic Convergence*) - 15 novembre 2013
        13. Ainsi s'abattent les ténèbres (*Darkness Falls*) - 22 novembre 2013
        14. Une lueur dans les ténèbres (*Light in the Dark*) - 22 novembre 2013
3. _**Livre trois : Le Changement**_
    1. Saison 3 (13 épisodes)
        1. Une bouffée d'air pur (*A Breath of Fresh Air*) - 27 juin 2014
        2. Renaissance (*Rebirth*) - 27 juin 2014
        3. La reine de la terre (*The Earth Queen*) - 27 juin 2014
        4. En proie au danger (*In Harm's Way*) - 11 juillet 2014
        5. Le clan du métal (*The Metal Clan*) - 11 juillet 2014
        6. De vieilles blessures (*Old Wounds*) - 18 juillet 2014
        7. Les premiers maîtres de l'air (*Original Airbenders*) - 18 juillet 2014
        8. Terreur dans la ville (*The Terror Within*) - 25 juillet 2014
        9. La planque (*The Stakeout*) - 1er août 2014
        10. Longue vie à la reine (*Long Live the Queen*) - 8 août 2014
        11. L'ultimatum (*The Ultimatum*) - 15 août 2014
        12. Embrasse le néant (*Enter the Void*) - 22 août 2014
        13. Le venin du Lotus Rouge (*Venom of the Red Lotus*) - 22 août 2014
4. _**Livre quatre : L'Équilibre**_
    1. Saison 4 (13 épisodes)
        1. Après toutes ces années (*After All These Years*) - 3 octobre 2014
        2. Korra, seule (*Korra Alone*) - 10 octobre 2014
        3. Le couronnement (*The Coronation*) - 17 octobre 2014
        4. Vocation (*The Calling*) - 24 octobre 2014
        5. L'ennemi aux portes de la ville (*Enemy at the Gates!*) - 31 octobre 2014
        6. La Bataille de Zaofu (*The Battle of Zaofu*) - 7 novembre 2014
        7. Retrouvailles (*Reunion*) - 14 novembre 2014
        8. Souvenirs (*Remembrances*) - 21 novembre 2014
        9. Par delà l'indomptable (*Beyond the Wilds*) - 28 novembre 2014
        10. Opération Beifong (*Operation Beifong*) - 5 décembre 2014
        11. La tactique de Kuvira (*Kuvira's Gambit*) - 12 décembre 2014
        12. Le jour du colosse (*Day of the Colossus*) - 19 décembre 2014
        13. Le dernier combat (*The Last Stand*) - 19 décembre 2014

[//]: # (Voici un extrait en anglais d'un programme pour calculer le nombre de minutes total à regarder la série "The Legend of Korra")

`Voici un extrait en anglais d'un programme pour calculer le nombre de minutes total à regarder la série "The Legend of Korra"`

```

int NumEp;
int WatchTimeMin = 24;
int TotalWatchTime;

cout << "How many episodes have you watched? ";
cin >> NumEp;

TotalWatchTime = NumEp * WatchTimeMin;

cout << "You have spent a total of " << TotalWatchTime << " minutes watching The Legend of Korra!";

```


















